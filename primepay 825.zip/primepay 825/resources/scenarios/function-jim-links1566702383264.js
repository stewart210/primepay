(function(window, undefined) {

  var jimLinks = {
    "4d821d40-6d84-449c-b745-3ab1302d22cb" : {
      "Two-line-item_47" : [
        "0cf28372-e7a9-4430-a42e-0bfca4c563d4"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Image_2" : [
        "0cf28372-e7a9-4430-a42e-0bfca4c563d4"
      ]
    },
    "d4cee271-df08-4194-8e3e-a9431ba791f3" : {
      "Two-line-item_26" : [
        "4d821d40-6d84-449c-b745-3ab1302d22cb"
      ],
      "Two-line-item_47" : [
        "0cf28372-e7a9-4430-a42e-0bfca4c563d4"
      ],
      "Button_1" : [
        "4d821d40-6d84-449c-b745-3ab1302d22cb"
      ]
    },
    "0cf28372-e7a9-4430-a42e-0bfca4c563d4" : {
      "Image_7" : [
        "4d821d40-6d84-449c-b745-3ab1302d22cb"
      ],
      "Button_1" : [
        "1cd6c00e-f55d-4208-a166-ad845ae9f320"
      ]
    },
    "88b8be61-2dd7-4888-b457-7c49494ea82e" : {
      "Text_4" : [
        "d4cee271-df08-4194-8e3e-a9431ba791f3"
      ]
    },
    "3c516720-4b00-4f3b-8882-591f39da28bb" : {
      "Button_1" : [
        "1cd6c00e-f55d-4208-a166-ad845ae9f320"
      ]
    },
    "1cd6c00e-f55d-4208-a166-ad845ae9f320" : {
      "Button_1" : [
        "88b8be61-2dd7-4888-b457-7c49494ea82e"
      ],
      "Image_7" : [
        "0cf28372-e7a9-4430-a42e-0bfca4c563d4"
      ],
      "Text_1" : [
        "3c516720-4b00-4f3b-8882-591f39da28bb"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);